<?php

namespace Xqueue\Maileon\Logger;

class Logger extends \Monolog\Logger
{

}
